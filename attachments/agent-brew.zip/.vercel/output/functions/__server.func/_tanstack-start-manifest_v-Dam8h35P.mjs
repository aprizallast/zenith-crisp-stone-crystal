//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dam8h35P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/tmp/cloned_repo/src/routes/__root.tsx",
		children: [
			"/",
			"/api/coingecko",
			"/api/copilot",
			"/api/dex",
			"/api/inspect",
			"/api/search",
			"/api/tokens",
			"/api/artwork/$address",
			"/api/visitors/leave",
			"/api/visitors/ping"
		],
		preloads: ["/assets/index-QLbx-s70.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-QLbx-s70.js"
		} }]
	},
	"/": {
		filePath: "/tmp/cloned_repo/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B9ATLkwH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
